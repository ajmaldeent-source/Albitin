---
name: compliance-check
description: Audit the store code and UI against India e-commerce, Legal Metrology, dark-pattern and DPDP rules in docs/compliance-checklist.md. Use after phases 03, 05, 06, 09 or before any release.
---

# Compliance check

1. Read `docs/compliance-checklist.md` fully.
2. For every check ID (CP-*, DP-*, LM-*, GST-*, DPDP-*, PAY-*), find the code, test or page that satisfies it.
   Search the codebase; do not assume.
3. Run the storefront locally and walk the flows: product page, cart, checkout (prepaid and COD),
   order confirmation, return request, grievance form, account deletion.
4. Produce a table in `reports/compliance-YYYY-MM-DD.md`:
   | Check ID | Status (Pass / Fail / Not built) | Evidence (file:line, test name or screenshot) | Fix needed |
5. For every Fail, open an item in `PROGRESS.md` under "Compliance gaps".
6. Summarise for the owner in 5 lines or fewer, plain language. Never mark Pass without evidence.
