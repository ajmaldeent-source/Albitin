---
name: sync-audit
description: Check that the site and Zoho Books agree — items, stock, orders, invoices, payments, credit notes — using the rules in docs/zoho-books-sync.md. Use after phases 01, 03, 04, 05 and whenever numbers look wrong.
---

# Sync audit

1. Read `docs/zoho-books-sync.md`.
2. Confirm `.env` points to the **test** Zoho Books organization unless the owner says otherwise in this session.
3. Run the reconcile script (`npm run reconcile -- --dry-run`) if it exists; otherwise query both sides read-only:
   - Items: every published variant has a valid `books_item_id`; price and GST rate match Books.
   - Stock: site available stock = Books stock minus active reservations.
   - Orders: every paid/confirmed order has `books_salesorder_id`; every shipped order has `books_invoice_id`.
   - Payments: every captured payment has `books_payment_id`; amounts match.
   - Returns: every refunded return has `books_creditnote_id`.
   - Sync jobs: list jobs in `failed` or retried more than 3 times.
4. Write `reports/sync-audit-YYYY-MM-DD.md` with counts, mismatches (IDs only, no customer personal data), and likely cause.
5. Never "fix" by writing to Zoho Books directly. Propose fixes; apply only through the sync queue after the owner agrees.
