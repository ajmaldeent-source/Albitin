# Phase 09 — Hardening and go-live

---

Read `CLAUDE.md` and `docs/compliance-checklist.md`. Ask me before touching any production account.

Do:
1. Security review: OWASP top 10 pass over API routes, auth, file uploads, webhooks; dependency audit; rate limits on login, OTP, grievance and webhook endpoints; security headers; CSRF where relevant. Fix findings.
2. Secrets: move to a secret manager for production; rotate test keys; confirm nothing secret in Git history.
3. Encryption at rest for database, backups and S3; daily automated backups with a tested restore.
4. Load test: checkout and product pages at 10× expected peak; fix slow queries; add caching/CDN rules.
5. DPDP: retention job (DPDP-09); breach runbook `docs/runbooks/breach.md` + tabletop drill notes; log masking review (DPDP-07).
6. Dark-pattern self-audit: walk every flow against DP-01 to DP-08; write `reports/dark-pattern-audit-YYYY.md`; publish the certificate page (CP-14).
7. Deployment per `docs/deployment.md`:
   - Storefront on **Netlify**: production site from `main`, staging from `staging`, deploy previews on PRs; env vars set in Netlify UI; catalog pages statically generated with revalidation to limit compute credits; confirm the Netlify plan will not pause the live site.
   - Backend on the always-on Mumbai host I choose (compare AWS EC2/Lightsail, Medusa Cloud, or a Mumbai VPS for me first, with monthly cost): infrastructure files, managed Postgres + Redis, Meilisearch, S3, health checks, zero-downtime deploys from GitHub Actions.
   - Cloudflare DNS: `www` → Netlify, `api` → backend. Staging first, then production plan.
8. Production cut-over checklist in `docs/runbooks/go-live.md`: switch Zoho to live org, Razorpay live keys, DNS, first full item import (dry-run, then real), smoke tests, rollback plan.
9. Monitoring: uptime checks, error tracking, queue depth, reconcile alerts.

Acceptance checklist:
- [ ] No high/critical security findings open
- [ ] Restore from backup tested
- [ ] Load test passes target
- [ ] Full `/compliance-check` shows Pass for every item, with evidence
- [ ] Lawyer + CA sign-off recorded in PROGRESS.md (owner task)
- [ ] Staging fully green; go-live runbook reviewed with me

Do not deploy to production until I type "approve go-live". Summarise in 5 lines.
