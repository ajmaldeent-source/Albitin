# Phase 03 — Checkout, Razorpay, COD + OTP, orders to Zoho Books

Before pasting: put Razorpay **test** key ID, key secret and webhook secret in `backend/.env`; MSG91/Gupshup test credentials if ready.

---

Read `CLAUDE.md`, `docs/zoho-books-sync.md` (contact.push, salesorder.push, salesorder.cancel), `docs/compliance-checklist.md` (DP-01, DP-02, DP-07, CP-15, CP-16, PAY-01 to PAY-05). Check current Razorpay docs for Orders API, Checkout, signature verification and webhooks.

Build:
1. Cart and checkout (guest allowed): address with Indian states and pin code validation, shipping options, COD option.
2. Stock reservation: on checkout start, reserve qty in `stock_reservation` for 15 minutes; release on expiry or cancel; available = `stock_mirror.available − active reservations`.
3. Price summary before payment: items, shipping, COD fee (if COD), estimated taxes (from synced GST rate), total. Nothing pre-ticked, nothing auto-added.
4. Razorpay: server creates Razorpay order; client opens Razorpay Checkout; server verifies payment signature before marking order paid. Webhook `payment.captured` / `payment.failed` with webhook-secret verification and event-ID dedupe.
5. `src/modules/cod`: eligibility rules (pin code allow-list, max order value, configurable in admin), COD fee, OTP via SMS/WhatsApp (hashed OTP, 5-minute expiry, 3 attempts), order status `awaiting_cod_confirmation` until verified.
6. On order paid or COD verified → enqueue `contact.push` then `salesorder.push` (reference_number = site order number, place of supply = ship-to state).
7. Cancellation before shipment → `salesorder.cancel`; refund prepaid via Razorpay refund API (refund record kept for Phase 04 payment sync).
8. Order confirmation page + email/SMS. Order history in customer account.
9. Cancellation charge setting off by default; can be enabled only with a "symmetric policy" confirmation.

Tests:
- Signature verification (valid, tampered).
- Webhook dedupe.
- Reservation expiry and race (two carts, last unit).
- COD OTP flow (success, expiry, too many attempts).
- Sales order job idempotent (retry does not duplicate in fake Books).

Acceptance checklist:
- [ ] Test-mode prepaid order creates a sales order in the test Books org with correct items, state, shipping
- [ ] COD order reaches Books only after OTP verification
- [ ] Cancelled order cancels the Books sales order and refunds in Razorpay test mode
- [ ] Two buyers cannot both buy the last unit
- [ ] Full price shown before payment; no pre-ticked boxes
- [ ] All tests pass

Run `/sync-audit` and `/compliance-check`. Update PROGRESS.md. Summarise in 5 lines.
