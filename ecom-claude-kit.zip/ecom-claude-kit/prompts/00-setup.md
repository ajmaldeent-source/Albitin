# Phase 00 — Project setup

Paste everything below into Claude Code.

---

You are building the store described in `CLAUDE.md`. Read `CLAUDE.md`, `README.md` and `docs/architecture.md` first.

Goal: a working local project with Medusa v2 backend + admin, a Next.js storefront, and local services.

Do this:
1. Check Node.js (20+), npm, Git and Docker versions. Tell me plainly if anything is missing and stop.
2. Initialise Git in this folder. Add a `.gitignore` covering `node_modules`, `.env*` (except `.env.example`), build output, `reports/` personal data.
3. Detect the environment. If running in GitHub Codespaces (`CODESPACES=true`), Postgres, Redis and Meilisearch already run from `.devcontainer/` at hosts `postgres`, `redis`, `meilisearch` — use those and skip Docker. Otherwise copy `templates/docker-compose.yml` to the root and start them. Read `docs/deployment.md`.
4. Create the Medusa v2 project in `backend/` and the Next.js storefront in `storefront/` using the official Medusa create tooling. Check current Medusa docs for the exact command; do not guess.
5. Copy `templates/.env.example` to `backend/.env.example` and `storefront/.env.example`, keeping only the variables each side needs. Create local `.env` files with safe local values; leave Zoho and Razorpay values blank.
6. Configure Medusa to use the local Postgres and Redis (event bus, cache, workflow engine).
7. Set region India, currency INR, tax-inclusive display, default sales channels: `D2C` and `B2B`.
8. Add root scripts: `dev`, `typecheck`, `lint`, `test`. Set up ESLint, Prettier, Vitest or Jest (whichever Medusa recommends now).
9. Copy `templates/PROGRESS.md` and `templates/netlify.toml` to the root. Make sure the storefront builds with `npm run build` inside `storefront/` so Netlify can deploy it. Storefront runs on port 8000, backend on 9000. In Codespaces, set CORS and `NEXT_PUBLIC_MEDUSA_BACKEND_URL` to the forwarded `*.app.github.dev` URLs.
10. Create empty module folders listed in `docs/architecture.md` with a README each saying its purpose.
11. Commit: "chore: project setup".

Acceptance checklist (tick in PROGRESS.md):
- [ ] Postgres, Redis and Meilisearch reachable (Codespaces services or Docker)
- [ ] `npm run build` in `storefront/` succeeds (Netlify-ready)
- [ ] Medusa admin opens locally and I can log in as an admin user you created
- [ ] Storefront home page loads locally
- [ ] `npm run typecheck && npm run lint && npm test` pass
- [ ] Region India / INR configured
- [ ] No secrets committed

Finish by telling me in 5 short lines: what works, how to start it, what I must do next.
