# Phase 04 — Fulfilment, invoices, payments into Zoho Books

---

Read `CLAUDE.md` and `docs/zoho-books-sync.md` (invoice.create, payment.push).

Build:
1. Admin fulfilment queue: filter by status, payment type, warehouse. Pick list and packing slip PDFs.
2. Manual shipment entry first (courier, AWB). Design a `ShippingProvider` interface so Shiprocket can plug in later; build the Shiprocket adapter behind a feature flag only if credentials exist.
3. On shipment created → `invoice.create` (sales order → invoice in Books). Store `books_invoice_id`. Show "Download invoice" in customer account by fetching the PDF from Books via the client (cache in S3).
4. Flag shipments with value > ₹50,000 as "e-way bill required" in admin and block dispatch until the e-way bill number (generated in Books) is entered.
5. Payments:
   - Prepaid: on capture, `payment.push` (record against invoice if exists, else as advance against sales order per Books docs; reference = Razorpay payment ID).
   - COD: admin uploads courier COD remittance CSV; match AWB → order; `payment.push` for each; show unmatched rows.
   - Prepaid refunds from Phase 03: record refund in Books.
6. Delivery status updates (manual now, provider webhooks later) and customer notifications.
7. RTO (returned to origin) for COD: mark order RTO, release to restock flow (Phase 05), cancel invoice if allowed by Books, else credit note.

Tests: invoice job idempotent; payment matching; remittance CSV parsing (good, duplicate, unknown AWB); e-way bill block.

Acceptance checklist:
- [ ] Shipping an order creates a Books invoice; customer can download it
- [ ] Prepaid payment appears in Books against the right invoice
- [ ] COD remittance upload records payments; unmatched rows listed
- [ ] Orders > ₹50,000 cannot dispatch without e-way bill number
- [ ] RTO path works end to end in test org

Run `/sync-audit`. Update PROGRESS.md. Summarise in 5 lines.
