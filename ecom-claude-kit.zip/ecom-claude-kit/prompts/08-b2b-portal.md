# Phase 08 — B2B portal

---

Read `CLAUDE.md`, `docs/data-model.md` (b2b tables) and `docs/zoho-books-sync.md` (contact.push for B2B).

Build `src/modules/b2b` + storefront `/business` area (same site, `B2B` sales channel):
1. Business sign-up: company name, GSTIN (format check + optional GST verification API if owner adds one), PAN, addresses per GSTIN state, contact person. Status pending until admin approves.
2. On approval: customer group `B2B`, credit limit, payment terms (prepaid / net 15 / net 30), price list; enqueue `contact.push` with GSTIN and terms.
3. Company sub-users: admin and buyer roles; buyers can order, admins manage users and see statements.
4. Pricing: Medusa price lists per group or per company; tiered quantity breaks; MOQ per product; prices shown ex-GST and incl. GST.
5. Ordering: quick order by SKU + qty, CSV bulk upload with row-level errors, re-order from history, save carts.
6. Quotes: request for quote on cart; admin edits prices; buyer accepts → order.
7. Credit: block order if outstanding + order total > credit limit unless owner approves. Outstanding pulled from Books (contact receivables) on a schedule.
8. Pay later: order placed on terms creates the Books sales order and invoice on shipment; buyer pays via Razorpay payment link from statement page; payment syncs as in Phase 04.
9. Statement page: invoices, payments, credit notes, outstanding (from Books).

Tests: GSTIN validation, MOQ and tier pricing, credit block, CSV upload errors, quote acceptance, B2B contact sync with GSTIN.

Acceptance checklist:
- [ ] Approved business buyer sees contract prices; retail buyer never does
- [ ] Bulk CSV order of 50 lines works with clear errors
- [ ] Credit limit blocks correctly and owner override works
- [ ] B2B invoice in Books carries buyer GSTIN and correct place of supply
- [ ] Statement matches Books

Run `/sync-audit`. Update PROGRESS.md. Summarise in 5 lines.
