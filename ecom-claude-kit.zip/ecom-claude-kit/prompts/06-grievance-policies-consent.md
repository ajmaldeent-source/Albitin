# Phase 06 — Grievance desk, policy pages, consent (2027 rules + DPDP)

---

Read `CLAUDE.md` and all of `docs/compliance-checklist.md`. This phase closes CP-01 to CP-06, CP-14, CP-15, CP-17, CP-18, DPDP-01 to DPDP-05, DPDP-10.

Build:
1. `src/modules/grievance`:
   - Public grievance form (logged-in or guest with OTP), linked to order if given.
   - On create: send complainant a copy of the complaint exactly as recorded (email + SMS link).
   - Timers: `ack_due_at` = created + 48 h, `resolve_due_at` = created + 1 month. Alerts to grievance officer at 36 h and day 25; escalation to owner on breach.
   - NCH docket number field; NCH partner ID from `business_entity`.
   - Admin queue sorted by due time; SLA report.
2. Policy pages (admin-editable, versioned): Terms, Privacy notice, Returns & Refunds, Shipping, Cancellation, Grievance Redressal, Dark-pattern self-audit certificate. Show last-updated date.
3. `src/modules/consent`:
   - Plain-language privacy notice at signup and checkout; purposes itemised.
   - Separate opt-ins (order updates are service messages; marketing via WhatsApp, SMS, email each separate, unchecked by default).
   - Withdraw in one click from account page. Log every change in `consent_record` with notice version.
4. Customer data rights: view, download (JSON/CSV), correct, request deletion → `data_request` with due date and admin queue. Deletion keeps legally required tax records, anonymises the rest.
5. Reviews: only verified buyers; no filtering by star rating; moderation reasons logged.
6. Data-protection contact on site.
7. Ensure the Books invoice template shows the business name prominently (owner action in Books; add a checklist item to PROGRESS.md).

Tests: SLA timers and alerts (fake clock), complaint copy sent, consent default unchecked, withdrawal logged, data export completeness, deletion anonymisation.

Acceptance checklist:
- [ ] Complaint copy received within 1 minute of filing
- [ ] 36-hour and 25-day alerts fire in test with fake clock
- [ ] All consent boxes unchecked by default; withdrawal is one click
- [ ] Customer can download and delete their data
- [ ] All policy pages live and linked in footer

Run `/compliance-check`. Update PROGRESS.md. Summarise in 5 lines.
