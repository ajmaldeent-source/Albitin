# Phase 07 — Owner dashboard, roles, nightly reconcile

---

Read `CLAUDE.md`, `docs/zoho-books-sync.md` (section 5) and the roles table in the blueprint.

Build:
1. Staff roles with least privilege: Owner, Operations manager, Catalog manager, Warehouse staff, Finance (site view), Support/Grievance officer. Warehouse role never sees prices or customer phone numbers. 2FA for all staff.
2. `audit_log` on every staff create/update/delete; admin viewer with filters.
3. Owner dashboard (admin home): today/7-day/30-day sales, orders by status, prepaid vs COD share, COD RTO rate, return rate, top products, low stock, grievance SLA status, sync health (queued/failed/dead, last reconcile result). Link out to Zoho Books reports for finance numbers rather than duplicating them.
4. `reconcile.nightly` job at 02:00 IST: all checks in sync spec section 5; JSON report in `reports/`; dashboard tile; alert to owner by email and WhatsApp on any failure.
5. `npm run reconcile -- --dry-run` CLI.
6. Alerts config page (who gets what).

Tests: role permission matrix (each role blocked from forbidden routes), reconcile detects each mismatch type using fake Books data.

Acceptance checklist:
- [ ] Each role sees only what it should (tested)
- [ ] Dashboard loads in < 2 s with seeded data
- [ ] Reconcile catches a deliberately broken order, payment and stock record
- [ ] Owner receives alert on failure

Run `/sync-audit`. Update PROGRESS.md. Summarise in 5 lines.
