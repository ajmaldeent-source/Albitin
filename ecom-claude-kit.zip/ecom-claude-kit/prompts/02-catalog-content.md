# Phase 02 — Catalog content, legal fields, search, price display

---

Read `CLAUDE.md`, `docs/compliance-checklist.md` (CP-07 to CP-13, LM-01 to LM-04, DP-03, DP-08) and `docs/data-model.md`.

Build:
1. `src/modules/catalog-compliance`:
   - Legal Metrology fields on variants (manufacturer/packer/importer, net quantity, unit, consumer care, country of origin, is_imported, importer, best_before).
   - Publish gate: a product cannot be published if a required field is empty. Clear admin error listing missing fields.
   - Admin form section "Legal declarations" with help text in plain English.
2. `src/modules/price-history`:
   - Service `getPriorPrice(variantId, at)` = lowest price in the 30 days before `at`.
   - Strike-through / discount badge on storefront only when current price < prior price; the shown "was" price = prior price. No manual "was" price field anywhere.
3. `business_entity` table + admin settings page (legal name, address, GSTINs, PAN, CIN, grievance officer, LMPC number, NCH partner ID).
4. Storefront:
   - Product listing, filters (category, price, country of origin), product detail page.
   - Product page shows: price incl. taxes, MRP, legal declarations block, return/refund/exchange/warranty/delivery/payment modes block (content from admin-editable policy snippets), stock state from real data only.
   - Footer + Contact page from `business_entity`.
   - Mobile-first, fast, accessible (labels, contrast, keyboard). Use the frontend-design approach: clean, trustworthy, not template-looking.
5. Search with Meilisearch: index name, SKU, category, attributes. Ranking rules documented in a new `docs/search-ranking.md` and implemented exactly. A `sponsored` flag that, if used, always renders a "Sponsored" label.
6. Seed script with 10 realistic home/general goods from the test Books org data.

Tests:
- Publish gate blocks incomplete products.
- Prior-price calculation edge cases (no history, price rise, multiple drops, price list prices).
- Sponsored label always shown when flag set.

Acceptance checklist:
- [ ] Incomplete product cannot publish
- [ ] Product page shows every LM-01 declaration
- [ ] Discount badge uses 30-day lowest price, verified by test
- [ ] Country-of-origin filter works
- [ ] `docs/search-ranking.md` exists and matches code
- [ ] Lighthouse mobile performance and accessibility ≥ 90 on product page

Update PROGRESS.md and summarise in 5 lines.
