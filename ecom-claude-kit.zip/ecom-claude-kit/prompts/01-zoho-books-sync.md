# Phase 01 — Zoho Books client + item and stock sync

Before pasting: put your **test** Zoho Books organization ID, OAuth client ID, client secret and refresh token in `backend/.env`. Do not paste them into chat.

---

Read `CLAUDE.md` and `docs/zoho-books-sync.md` fully. Then read the official Zoho Books API v3 docs for: OAuth (India data centre), items, item stock / warehouses, contacts, sales orders, invoices, credit notes, customer payments, rate limits, webhooks/workflow rules. Note any difference from our spec and update the spec file first.

Build:
1. `src/modules/zoho-books`:
   - `ZohoAuth`: refresh-token flow, access token cached in Redis with expiry, Redis lock to prevent parallel refresh, refresh-once-on-401.
   - `ZohoBooksClient` interface + real implementation: typed methods for items, stock, contacts, sales orders, invoices, payments, credit notes. Timeouts, retry on 5xx/429 with backoff, client-side rate limiter configured from env.
   - `FakeZohoBooksClient` for tests, loading fixtures from `test/fixtures/zoho/`.
   - Logs never include tokens or personal data.
2. `src/modules/books-sync`:
   - `sync_job` and `webhook_event` tables (see `docs/data-model.md`).
   - Queue on Redis with per-entity ordering keys, exponential backoff, `dead` after 5 attempts.
   - Jobs: `items.pull`, `stock.pull`. Scheduled every 15 minutes (`src/jobs`) and on webhook.
   - `stock_mirror` table; variant fields from `docs/data-model.md` (books_item_id, hsn, gst_rate, mrp).
   - Write `price_history` row whenever a synced price changes (create the table now).
   - Inactive item in Books → variant unpublished on site.
3. Webhook endpoint `POST /hooks/zoho-books/:topic` protected by shared secret; stores raw payload; enqueues job; returns 200 fast.
4. Admin page "Books sync": last sync time, queued/failed/dead counts, retry button for dead jobs.
5. Script `npm run books:import` for first full import from the test org (dry-run flag supported).
6. Guard: refuse to run imports/tests if `ZOHO_ENV=production` unless `--confirm-production` is passed.

Tests:
- Unit: token refresh, lock, 401 retry, rate limiter, backoff.
- Integration with fake client: item create/update/deactivate, price change → price_history row, stock update.

Acceptance checklist:
- [ ] Import pulls all test-org items into Medusa with correct SKU, price, HSN, GST rate, MRP
- [ ] Changing price in Books updates the site within 15 minutes (or instantly via webhook) and logs price history
- [ ] Changing stock in Books updates `stock_mirror`
- [ ] Killing Redis mid-job then restarting resumes jobs without duplicates
- [ ] Dead jobs visible and retryable in admin
- [ ] All tests pass

Finish with `/sync-audit`, update PROGRESS.md, and give me a 5-line summary.
