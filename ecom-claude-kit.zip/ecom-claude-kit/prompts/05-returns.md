# Phase 05 — Returns (RMA), QC, refunds, credit notes

---

Read `CLAUDE.md`, `docs/zoho-books-sync.md` (creditnote.push) and `docs/compliance-checklist.md` (CP-07, GST-02).

Build on Medusa's built-in returns/exchanges where possible; add `src/modules/rma` for rules and QC.

1. Customer return request from order page: pick lines and qty, reason (list), photos (S3, size limit), refund method (original source; for COD collect UPI ID or bank details — encrypted).
2. Rules engine (admin-configurable): return window days per category, non-returnable categories, auto-approve conditions (e.g. damaged on arrival with photo within 48 h), else manual review.
3. Statuses: requested → approved / rejected → pickup scheduled → received → QC graded → resolved (refund / exchange / store credit) → closed. Customer sees status and gets notifications at each step.
4. QC grade: A = restock (stock adjustment happens in Books — create an admin task or Books inventory adjustment per docs), B = refurbish, C = scrap/write-off.
5. Refund only after QC pass (or for auto-approved damage cases, after pickup scan if owner enables it). Prepaid: Razorpay refund API. COD: payout record (manual payout now).
6. `creditnote.push` against the Books invoice for returned lines; record refund in Books.
7. Exchange: new zero-value or price-difference order linked to the return; follows normal order sync.
8. Rejected return: reason shown; reverse-ship back option.
9. Admin returns queue with SLA ageing.

Tests: window rules, non-returnable block, refund-after-QC rule, credit note idempotent, exchange price difference.

Acceptance checklist:
- [ ] Customer can raise a return with photos in under 1 minute on mobile
- [ ] Refund never issued before QC pass (unless owner rule allows)
- [ ] Credit note appears in test Books org against correct invoice
- [ ] COD refund details stored encrypted and masked in admin
- [ ] Exchange flow creates linked order and syncs

Run `/sync-audit` and `/compliance-check`. Update PROGRESS.md. Summarise in 5 lines.
