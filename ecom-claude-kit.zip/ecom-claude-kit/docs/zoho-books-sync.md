# Zoho Books sync specification

Zoho Books is the master for items, stock and every tax document.
The site syncs through a Redis-backed job queue. Request handlers never call Zoho directly.

> **Verify before coding.** Endpoint paths, field names, scopes and rate limits below are the expected shape.
> Confirm each one against the official Zoho Books API v3 docs for the India data centre before use.
> If the docs differ, the docs win; update this file.

## 1. Connection

| Item | Value |
| --- | --- |
| Data centre | India (`.in`) |
| API base | `https://www.zohoapis.in/books/v3` |
| Accounts (OAuth) base | `https://accounts.zoho.in` |
| Auth type | OAuth 2.0, server-based client, offline access (refresh token) |
| Request header | `Authorization: Zoho-oauthtoken <access_token>` |
| Organization | `organization_id` query parameter on every call |
| Scopes | Least privilege: items, contacts, sales orders, invoices, credit notes, customer payments, settings read. Confirm exact scope names in docs. |

Token handling:
- Store the refresh token encrypted (env/secret manager). Never log it.
- Cache the access token in Redis with its expiry; refresh shortly before expiry.
- One refresh at a time (Redis lock) so parallel workers do not race.
- On `401`, refresh once and retry once; then fail the job.

Rate limits:
- Zoho enforces per-minute and per-day API limits that depend on plan. Read current numbers from docs and put them in config, not code.
- Client-side limiter in the Zoho client (token bucket). Back off on `429`.
- Cache item reads; batch where the API allows.

## 2. Ownership matrix

| Data | Master | Direction | Notes |
| --- | --- | --- | --- |
| Item, SKU, HSN, GST rate, MRP, selling price | Books | Books → site | Site may add content fields only |
| Stock per warehouse | Books | Books → site | Site holds checkout reservations only |
| Product images, descriptions, Legal Metrology display, SEO | Site | — | Not sent to Books |
| Retail customer contact | Site creates, Books stores | Site → Books | Create on first paid order |
| B2B contact (GSTIN, terms, credit limit) | Site approves, Books stores | Site → Books | Create on B2B approval |
| Sales order | Books | Site → Books | On paid / COD-confirmed order |
| Invoice | Books | Site triggers | On shipment |
| E-invoice IRN, e-way bill | Books | — | Configure inside Books |
| Customer payment | Books | Site → Books | On Razorpay capture / COD remittance |
| Credit note + refund | Books | Site → Books | On return QC pass / cancellation after invoice |
| Vendors, POs, bills, receipts | Books | — | Staff work in Books |

## 3. Sync jobs

Every job: `type`, `direction`, `entity_id`, `payload`, `status` (queued, running, done, failed, dead),
`attempts`, `next_run_at`, `last_error`, `books_ref`. Store in `sync_job` table; Redis drives execution.

Retry: exponential backoff (1m, 5m, 15m, 1h, 6h). After 5 failures → `dead` + admin alert.

| Job | Trigger | Steps | Idempotency |
| --- | --- | --- | --- |
| `items.pull` | Books webhook (item created/updated) + scheduled every 15 min | Fetch changed items; upsert variant by `books_item_id`; write `price_history` row if price changed; unpublish if item inactive | Upsert by `books_item_id` |
| `stock.pull` | Books webhook (stock change) + every 15 min | Fetch stock per item per warehouse; update `stock_mirror.available` | Overwrite with latest |
| `contact.push` | First paid order / B2B approval | Search Books contact by email or phone (B2B: GSTIN); create if missing; save `books_contact_id` | Search before create |
| `salesorder.push` | Order paid (prepaid) or COD confirmed | Ensure contact; create sales order with `reference_number = site order number`, line items by `books_item_id`, place of supply = ship-to state code, shipping charge line; save `books_salesorder_id` | Search by `reference_number` before create |
| `salesorder.cancel` | Order cancelled before invoice | Void/cancel sales order | No-op if already void |
| `invoice.create` | Shipment created | Convert sales order to invoice (or create invoice linked to it); save `books_invoice_id`; e-way bill handled in Books if value > ₹50,000 | Skip if `books_invoice_id` set |
| `payment.push` | Razorpay `payment.captured` webhook / COD remittance file | Record customer payment against invoice (or as advance against sales order if not invoiced yet); reference = gateway payment ID | Search by reference before create |
| `creditnote.push` | Return QC pass, or cancel after invoice | Create credit note against invoice for returned lines; record refund; save `books_creditnote_id` | Skip if set |
| `reconcile.nightly` | 02:00 IST daily | Compare site vs Books (see section 5); write report; alert on gaps | Read-only |

Ordering rule: for one order, jobs run in sequence (contact → salesorder → invoice → payment → creditnote).
Use a per-order queue key so they never run out of order.

## 4. Webhooks from Books

- Set up workflow rules in Zoho Books that call the site webhook on item and stock changes.
- Endpoint: `POST /hooks/zoho-books/:topic` with a shared secret in a header or query token (Books cannot sign like Razorpay; use a long random secret + IP allow-list if available).
- Store raw payload in `webhook_event`; enqueue the matching pull job; return `200` fast.
- Webhooks can be missed: the 15-minute scheduled pulls are the safety net.

## 5. Reconcile rules (nightly)

| Check | Pass condition |
| --- | --- |
| Published variants | Each has a valid, active `books_item_id` |
| Price | Site price = Books rate (or price list rate) |
| GST rate / HSN | Site copy = Books |
| Stock | `stock_mirror.available` = Books stock (± reservations) |
| Paid orders > 1 h old | Have `books_salesorder_id` |
| Shipped orders > 24 h old | Have `books_invoice_id` |
| Captured payments > 1 h old | Have `books_payment_id`, amount matches |
| Refunded returns | Have `books_creditnote_id` |
| Sync jobs | None `dead`; none queued > 1 h |

Output: `reports/reconcile-YYYY-MM-DD.json` + admin dashboard tile + email/WhatsApp alert to owner on any failure.

## 6. Testing

- `ZohoBooksClient` behind an interface. Tests use a fake client with recorded fixtures in `test/fixtures/zoho/`.
- Contract tests (manual, opt-in) run against the **test Zoho org** only: `npm run test:zoho-contract`.
- Guard: if `ZOHO_ENV=production`, refuse to run tests or seed scripts.
