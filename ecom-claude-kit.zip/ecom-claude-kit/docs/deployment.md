# Development and deployment

## Where each part runs

| Part | Development | Production |
| --- | --- | --- |
| Code editing + Claude Code | GitHub Codespaces | — |
| Postgres, Redis, Meilisearch | Dev container services (Codespaces) | Managed services in Mumbai region |
| Medusa backend + admin + workers | Codespaces, port 9000 | Long-running Node host in Mumbai (e.g. AWS EC2/Lightsail or Medusa Cloud) — NOT Netlify |
| Next.js storefront + B2B portal | Codespaces, port 8000 | **Netlify** |
| Zoho Books | Test organization | Live organization |
| Razorpay | Test keys | Live keys |

Why the backend is not on Netlify: Medusa needs an always-on server, background workers,
scheduled jobs (15-minute Books sync, nightly reconcile) and Redis. Netlify runs static files and short serverless functions.

## GitHub Codespaces

1. Push this kit to a **private** GitHub repo.
2. Add Codespaces secrets: GitHub → Settings → Codespaces → Secrets (or repo Settings → Secrets → Codespaces).
   Names are listed in `.devcontainer/devcontainer.json` → `secrets`. They arrive as environment variables; no `.env` file needed for them.
3. Create a codespace on the repo. Choose **4-core** machine (Medusa + Next.js + 3 services need it).
4. Wait for setup. Claude Code installs automatically. In the terminal run `claude` and log in.
5. Paste `prompts/00-setup.md`.

Free usage: personal GitHub Free accounts get 120 core-hours and 15 GB storage per month (Pro: 180 / 20).
Core-hours count per core: a 4-core machine uses 4 per hour, so ~30 hours/month free.
- Stop the codespace when not working (it auto-stops after idle timeout; set it to 30 min).
- Delete old codespaces to free storage.
- Set a spending limit of $0 or a small budget so you are never billed by surprise.

Codespaces URLs: forwarded ports get URLs like `https://<codespace-name>-9000.app.github.dev`.
Set storefront `NEXT_PUBLIC_MEDUSA_BACKEND_URL` and backend CORS to these URLs while developing.
Port 9000 must be set to **Public** visibility only when testing webhooks (Zoho/Razorpay); set it back to Private after.

## Netlify (storefront)

1. Copy `templates/netlify.toml` to repo root.
2. Netlify → Add new site → Import from GitHub → pick the repo. Netlify reads `netlify.toml`.
3. Set environment variables in Netlify UI (listed in `netlify.toml`). Never put secrets with `NEXT_PUBLIC_` prefix.
4. Deploy previews: every pull request gets a preview URL — use it for owner review.
5. Custom domain: add `www.yourstore.in`, enable HTTPS.

Plan advice:
- Free plan has 300 credits/month; deploys, bandwidth and server compute all use credits, and the site **pauses** when credits run out.
- Server-rendered pages use compute credits on every request. Use static generation + revalidation for product and category pages; keep cart/checkout dynamic.
- For a live store, move to a paid plan before launch so the shop never pauses. Check Netlify's current terms for commercial use.
- Check whether your plan lets you choose a function region near India; lower latency for server-rendered pages.

## Backend production host (choose before Phase 09)

Requirements: Node 22, always-on, 2+ vCPU / 4 GB RAM to start, Mumbai region, managed Postgres + Redis, daily backups, HTTPS.
Options to compare in Phase 09: AWS (EC2 or Lightsail + RDS + ElastiCache), Medusa Cloud, or another Mumbai-region VPS.
Claude Code will write the infrastructure files for the chosen option.

## Branch flow

`main` = production · `staging` = staging · feature branches → pull request → Netlify preview → merge.
