# Architecture overview

Full blueprint with diagrams: the "E-commerce Platform Blueprint — India D2C + B2B" doc.
This file is the short version Claude Code works from.

## Layers

```
Retail customer      B2B buyer           Staff
      |                  |                  |
Storefront (Next.js) B2B portal (Next.js) Admin (Medusa admin + extensions)
      \__________________|__________________/
                         |
        Cloudflare CDN + WAF  ->  API layer (auth, staff 2FA, rate limits)
                         |
        Commerce core: Medusa.js v2
        - Catalog content      - Pricing & promos (+ price history)
        - Orders (OMS)         - Stock mirror (read from Books + reservations)
        - Returns (RMA)        - Books sync module   *custom
        - B2B accounts *custom - CRM & grievance     *custom
                         |
      +------------------+-------------------------+
      | Data (AWS Mumbai)|   External services     |
      | PostgreSQL       |   Zoho Books (MASTER)   |
      | Redis (queue)    |   Razorpay              |
      | S3 (files)       |   COD OTP via MSG91     |
      | Meilisearch      |   Shiprocket (later)    |
      |                  |   Email (SES)           |
      +------------------+-------------------------+
```

## Custom Medusa modules

| Module | Folder | Responsibility |
| --- | --- | --- |
| `zoho-books` | `src/modules/zoho-books` | OAuth token handling, typed API client, ID mapping |
| `books-sync` | `src/modules/books-sync` + `src/workflows/books-*` + `src/jobs` | Sync jobs, queue, retries, reconcile |
| `catalog-compliance` | `src/modules/catalog-compliance` | Legal Metrology fields, publish gate |
| `price-history` | `src/modules/price-history` | Price log, 30-day prior price |
| `cod` | `src/modules/cod` | COD eligibility, OTP confirm, COD fee |
| `rma` | `src/modules/rma` (extend Medusa returns) | Return rules, QC grade, resolution |
| `grievance` | `src/modules/grievance` | Tickets, SLA timers, escalation, complaint copy |
| `consent` | `src/modules/consent` | Consent records, notices, data-principal requests |
| `b2b` | `src/modules/b2b` | Company accounts, sub-users, credit limit, terms, quotes |
| `audit-log` | `src/modules/audit-log` | Staff action log |

Use Medusa built-ins for: products/variants, carts, orders, customers, customer groups,
price lists, promotions, fulfilment, payments, regions, sales channels.

## Key flows

1. **Order to cash:** cart → checkout → Razorpay or COD OTP → order → Books sales order →
   pick/pack/ship → Books invoice (+ e-way bill if > ₹50,000) → payment recorded in Books.
2. **Procure to pay:** done entirely inside Zoho Books. Site only receives stock changes.
3. **Return to refund:** request → approve/reject → reverse pickup → QC grade →
   refund or exchange → Books credit note → stock back if grade A.

## Environments

| Env | Zoho Books org | Razorpay | Data |
| --- | --- | --- | --- |
| local | Test org | Test keys | Docker |
| staging | Test org | Test keys | Cloud, seeded |
| production | Live org | Live keys | Cloud, backed up daily |
