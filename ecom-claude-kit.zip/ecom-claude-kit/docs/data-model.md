# Site data model

Medusa built-in tables cover products, variants, carts, orders, customers, customer groups,
price lists, promotions, fulfilment, payments. Add the custom tables and fields below.
All money in paise (integer). All times UTC.

## Fields added to built-ins (via module links or metadata models)

| Entity | Added fields |
| --- | --- |
| Product variant | `books_item_id`, `hsn`, `gst_rate`, `mrp`, `net_quantity`, `unit`, `country_of_origin`, `manufacturer_name`, `manufacturer_address`, `packer_or_importer_name`, `packer_or_importer_address`, `consumer_care_contact`, `best_before` (nullable), `is_imported`, `importer_name`, `books_synced_at` |
| Customer | `books_contact_id`, `type` (retail/b2b) |
| Order | `books_salesorder_id`, `books_invoice_id`, `place_of_supply_state`, `cod_confirmed_at` |
| Payment | `books_payment_id`, `gateway_payment_id` |
| Fulfilment / shipment | `awb`, `courier`, `eway_bill_no`, `cod_amount`, `cod_remitted_at` |

## Custom tables

| Table | Key columns |
| --- | --- |
| `business_entity` | legal_name, trade_name, pan, cin, gstins (json), registered_address, grievance_officer_name, grievance_officer_phone, grievance_officer_email, lmpc_number, nch_partner_id |
| `stock_mirror` | variant_id, warehouse_code, available, reserved, synced_at |
| `stock_reservation` | id, cart_id, variant_id, qty, expires_at |
| `price_history` | variant_id, price, price_list_id (nullable), valid_from, valid_to |
| `b2b_account` | id, company_name, gstin, credit_limit, outstanding, payment_terms_days, status, approved_by, books_contact_id |
| `b2b_user` | b2b_account_id, customer_id, role (admin/buyer) |
| `quote` | b2b_account_id, lines (json), status, valid_until |
| `return_request` | id, order_id, lines (json), reason, photos (json), status, qc_grade, resolution, refund_method, books_creditnote_id |
| `grievance` | id, customer_id, order_id, category, description, recorded_copy_sent_at, created_at, ack_due_at, ack_at, resolve_due_at, resolved_at, nch_docket, status, escalation_level |
| `consent_record` | customer_id, purpose, notice_version, given_at, withdrawn_at, channel |
| `data_request` | customer_id, type (access/correct/erase), status, due_at, closed_at |
| `sync_job` | id, type, direction, entity_id, payload (json), status, attempts, next_run_at, last_error, books_ref |
| `webhook_event` | id, source, topic, external_id, payload (json), received_at, processed_at |
| `audit_log` | actor_id, action, entity, entity_id, before (json), after (json), ip, created_at |
| `cod_otp` | order_id, phone_hash, otp_hash, expires_at, attempts, verified_at |

## Rules

- Never store full card details. Never store OTPs in plain text.
- `price_history` rows are append-only.
- `audit_log` and `webhook_event` are append-only.
- Retention: keep tax-linked order data per GST record-keeping rules (confirm period with CA); erase other personal data on request or after the retention period.
