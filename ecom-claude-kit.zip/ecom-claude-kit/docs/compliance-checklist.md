# India compliance checklist (testable)

Technical checklist, not legal advice. Owner must get lawyer + CA sign-off before launch.
"2027" = Consumer Protection (E-Commerce) Amendment Rules 2026, in force 1 Jan 2027.
DPDP core duties apply around 13 May 2027.

Each check needs evidence: a test, a file:line, or a screenshot.

## Consumer Protection (E-Commerce) Rules

| ID | Check | From |
| --- | --- | --- |
| CP-01 | Footer and Contact page show legal name, address, phone, email from `business_entity` | Now |
| CP-02 | Grievance officer name, contact and designation shown on site | Now |
| CP-03 | Grievance acknowledged ≤ 48 h; timer + escalation alert at 36 h | Now |
| CP-04 | Grievance resolved ≤ 1 month; alert at day 25 | Now |
| CP-05 | Complainant receives copy of complaint as recorded (email/SMS) on creation | 2027 |
| CP-06 | NCH docket field on grievance; NCH partner ID stored | 2027 |
| CP-07 | Return, refund, exchange, warranty, delivery, return-shipping cost, payment modes shown on every product page and at checkout | Now |
| CP-08 | Best-before / use-before date shown where applicable | 2027 |
| CP-09 | Imported goods show importer details and full country-of-origin name | Now / 2027 |
| CP-10 | Price-drop display shows prior price = lowest price in previous 30 days, computed from `price_history` | 2027 |
| CP-11 | Staff cannot type a manual "MRP was" / strike-through price | 2027 |
| CP-12 | Sponsored placements labelled "Sponsored" | 2027 |
| CP-13 | Search ranking rules documented in `docs/search-ranking.md` and match code | 2027 |
| CP-14 | Annual dark-pattern self-audit report stored; certificate page live | 2027 |
| CP-15 | All consent checkboxes unchecked by default | Now |
| CP-16 | Cancellation charge only if symmetric policy setting enabled | Now |
| CP-17 | Invoice shows seller name clearly (single-seller: business name on Books invoice template) | 2027 |
| CP-18 | No fake reviews; reviews only from verified buyers; no review suppression by rating | Now |

## Dark patterns (Guidelines 2023)

| ID | Check |
| --- | --- |
| DP-01 | Full price incl. shipping, COD fee, taxes shown before payment step (no drip pricing) |
| DP-02 | Nothing auto-added to cart (no basket sneaking) |
| DP-03 | Stock counts and timers come from real data only (no false urgency) |
| DP-04 | Decline / close buttons use neutral wording (no confirm shaming) |
| DP-05 | Any membership/subscription cancellable in as few steps as signup (no subscription trap) |
| DP-06 | Ads visually distinct from products (no disguised ads) |
| DP-07 | No forced account creation to see price; guest checkout available |
| DP-08 | No bait-and-switch: advertised price = checkout price |

## Legal Metrology

| ID | Check |
| --- | --- |
| LM-01 | Product cannot publish unless manufacturer/packer/importer name + address, common name, net quantity, MRP incl. taxes, consumer-care contact, country of origin are filled |
| LM-02 | These declarations shown prominently on the listing |
| LM-03 | Country-of-origin filter on catalog |
| LM-04 | LMPC registration number stored in `business_entity` |

## GST (handled mainly in Zoho Books)

| ID | Check |
| --- | --- |
| GST-01 | Every shipped order has a Books invoice with GSTIN, HSN, place of supply, correct CGST+SGST/IGST |
| GST-02 | Every refund after invoice has a Books credit note |
| GST-03 | E-way bill generated in Books for consignments > ₹50,000 |
| GST-04 | E-invoicing enabled in Books once turnover ≥ ₹5 crore (owner setting) |
| GST-05 | B2B buyer GSTIN validated (format + optional GST API check) before credit approval |

## DPDP Act + Rules

| ID | Check |
| --- | --- |
| DPDP-01 | Plain-language privacy notice at signup and checkout, purposes itemised |
| DPDP-02 | Separate opt-in per marketing channel; withdraw from account page in one step |
| DPDP-03 | Every consent change logged in `consent_record` |
| DPDP-04 | Customer can view, correct, download and request deletion of data |
| DPDP-05 | Data requests tracked with due dates in `data_request` |
| DPDP-06 | Encryption in transit (TLS) and at rest (DB, backups, S3) |
| DPDP-07 | Personal data masked in logs and for warehouse role |
| DPDP-08 | Breach response runbook in `docs/runbooks/breach.md`; drill done |
| DPDP-09 | Retention job erases inactive personal data except legally required records |
| DPDP-10 | Data-protection contact shown on site |

## Payments

| ID | Check |
| --- | --- |
| PAY-01 | Razorpay Checkout only; no card data on our servers or logs |
| PAY-02 | Razorpay payment signature verified server-side before marking paid |
| PAY-03 | Razorpay webhooks verified with webhook secret; deduped by event ID |
| PAY-04 | COD fee shown before order; COD limits by pin code and order value |
| PAY-05 | COD orders confirmed by OTP or WhatsApp before dispatch |
