# CLAUDE.md — Project rules for Claude Code

Read this file fully at the start of every session. Follow it over any default habit.

## 1. What we are building

An Indian e-commerce platform for one business that sells home and general goods.

- **Channels:** retail customers (D2C) and business buyers (B2B) on one site.
- **Back office:** the business's existing **Zoho Books** (Professional plan or higher).
- **Legal status:** inventory e-commerce entity (owns stock, sells direct). Not a marketplace.
- **Market:** India only. Currency INR. GST applies. Hindi/regional languages later.

Full specs live in `docs/`. Read the relevant doc before starting any phase.

## 2. Stack (do not change without asking the owner)

| Layer | Choice |
| --- | --- |
| Commerce backend | Medusa.js v2 (Node.js 20+, TypeScript) |
| Storefront + B2B portal | Next.js (App Router, TypeScript, Tailwind) |
| Admin | Medusa admin + custom admin extensions |
| Database | PostgreSQL |
| Queue / cache / events | Redis |
| Search | Meilisearch |
| Files | S3-compatible storage |
| Payments | Razorpay (UPI, cards, netbanking, EMI) + Cash on Delivery |
| Back office | Zoho Books API (India data centre) |
| Shipping (later) | Shiprocket |
| Messaging | MSG91 or Gupshup (SMS OTP, WhatsApp) |
| Dev environment | GitHub Codespaces (`.devcontainer/`); services reachable at hosts `postgres`, `redis`, `meilisearch` |
| Storefront hosting | Netlify (`netlify.toml`; static generation + revalidation for catalog pages) |
| Backend hosting | Always-on Node host in Mumbai region (not Netlify) — see `docs/deployment.md` |

## 3. The golden rule: Zoho Books is the master

Zoho Books owns: items, HSN, GST rates, MRP, stock, vendors, purchase orders, vendor bills,
sales orders, GST invoices, credit notes, e-invoice IRN, e-way bills, GST returns, payments ledger.

The site owns: product content (images, descriptions, Legal Metrology display), cart, checkout,
payments capture, customer accounts, B2B portal, returns requests, grievance desk, consent log,
30-day price history, policy pages.

Therefore:
- NEVER compute GST on the site for the legal invoice. Books issues tax documents.
  The site may show an estimated tax at checkout using the rate synced from Books.
- NEVER change stock on the site. Site only holds a short **reservation** during checkout.
- NEVER build a purchase-order, vendor or invoicing module on the site.
- Every write to Books goes through the **sync queue** (`docs/zoho-books-sync.md`). No direct calls from request handlers.
- Every synced record stores its Books ID (`books_item_id`, `books_contact_id`, `books_salesorder_id`, `books_invoice_id`, `books_creditnote_id`, `books_payment_id`).

## 4. Compliance rules that shape code (India)

These are product requirements, not optional polish. Details: `docs/compliance-checklist.md`.

1. **No dark patterns.** No fake scarcity, no countdown timers that are not real, no pre-ticked
   boxes, no auto-added cart items, no hidden fees. Show the full price (shipping, COD fee, taxes) before the payment step.
2. **Price drops** must show the prior price = lowest price in the 30 days before the drop. Compute it from `price_history`; never let staff type a "was" price.
3. **Sponsored** placements must show a visible "Sponsored" label.
4. **Search ranking** is rule-based and documented in `docs/search-ranking.md` (create it in Phase 2). No hidden boosts.
5. **Product pages** must show: manufacturer/packer/importer name and address, common name, net quantity, MRP incl. taxes, consumer-care contact, country of origin, best-before date where relevant. A product cannot publish if any required field is empty.
6. **Grievances:** acknowledge within 48 hours, resolve within 1 month, send the complainant a copy of the recorded complaint. Timers and escalation are mandatory.
7. **Consent (DPDP Act):** explicit opt-in, separate per purpose, withdrawable as easily as given, logged in `consent_record`.
8. **Cancellation charges** only if the business bears a similar charge when it cancels.
9. **Card data** never touches our servers. Razorpay Checkout only.

If a feature request conflicts with these rules, stop and tell the owner instead of building it.

## 5. Code conventions

- TypeScript strict mode everywhere. No `any` without a comment explaining why.
- Money: integer **paise** in the database and code. Format to ₹ only in the UI.
- Dates: store UTC; display Asia/Kolkata.
- Medusa v2 layout: custom modules in `src/modules/<name>`, workflows in `src/workflows`,
  API routes in `src/api`, subscribers in `src/subscribers`, scheduled jobs in `src/jobs`,
  admin extensions in `src/admin`. Follow Medusa docs for the current version; check them, do not guess APIs.
- Business logic goes in workflows/services, never in route handlers.
- All external calls (Zoho, Razorpay, Shiprocket, MSG91) wrapped in a client class with timeouts, retries and typed responses.
- Webhooks: verify signatures, store raw payload, process idempotently (dedupe on event ID).
- Secrets only from environment variables (Codespaces secrets in dev, host secret manager in production). Never print secrets in logs. Never commit `.env`.
- Storefront env vars with `NEXT_PUBLIC_` are public. Never put a secret behind that prefix.
- Personal data (phone, email, address) masked in logs.
- Every create/update/delete by staff writes an `audit_log` row.

## 6. Testing and done criteria

A task is done only when:
1. Code compiles with no TypeScript errors.
2. Unit tests cover new services; integration tests cover new API routes and workflows.
3. Zoho calls are tested against a mocked Zoho client (record/replay fixtures in `test/fixtures/zoho`).
4. The phase prompt's acceptance checklist is ticked in `PROGRESS.md`.
5. `PROGRESS.md` lists what changed, open issues, and next step.

Run before saying done: `npm run typecheck && npm run lint && npm test`.

## 7. How to work with the owner

- The owner is a business person, not a developer. Explain in short plain sentences.
- Ask before: changing the stack, adding a paid service, deleting data, changing a compliance rule, touching production.
- Prefer small commits with clear messages. One feature per branch.
- When unsure about Zoho Books or Medusa API details, read the official docs first. Never invent endpoints or fields.
- Update `PROGRESS.md` at the end of every session.

## 8. Useful commands (fill in as the project grows)

```bash
# In Codespaces, Postgres/Redis/Meilisearch already run (dev container). Outside Codespaces:
docker compose up -d          # local Postgres, Redis, Meilisearch
npm run dev                   # backend + admin (port 9000)
npm run dev --workspace=storefront   # storefront (port 8000)
npm test
npm run typecheck && npm run lint
```
