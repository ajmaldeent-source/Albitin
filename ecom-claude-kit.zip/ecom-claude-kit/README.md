# E-commerce Build Kit for Claude Code

India D2C + B2B store, back office on Zoho Books. Built phase by phase with Claude Code.

## What is inside

| Path | Purpose |
| --- | --- |
| `CLAUDE.md` | Rules Claude Code reads every session. Stack, golden rules, compliance. |
| `docs/architecture.md` | Short system overview |
| `docs/zoho-books-sync.md` | Exact sync spec between site and Zoho Books |
| `docs/data-model.md` | Site database tables |
| `docs/compliance-checklist.md` | India legal rules as testable checks |
| `prompts/00`–`09` | One prompt per build phase. Paste in order. |
| `templates/.env.example` | Every secret the app needs |
| `templates/docker-compose.yml` | Local Postgres, Redis, Meilisearch |
| `templates/PROGRESS.md` | Progress log Claude Code keeps updated |
| `.devcontainer/` | GitHub Codespaces setup: Node 22, Postgres, Redis, Meilisearch, Claude Code |
| `templates/netlify.toml` | Netlify config for the storefront |
| `docs/deployment.md` | Codespaces, Netlify and backend hosting guide |
| `.claude/settings.json` | Blocks Claude from reading your `.env` |
| `.claude/skills/` | Two reusable checks: `/compliance-check`, `/sync-audit` |

## Before you start (owner checklist)

- [ ] Claude plan with Claude Code access
- [ ] GitHub account (private repo) with Codespaces; spending limit set
- [ ] Netlify account linked to GitHub
- [ ] Backend host decided before Phase 09 (Netlify cannot run the backend)
- [ ] Zoho Books on **Professional** plan or higher (POs, inventory, e-invoicing)
- [ ] Zoho Books **sandbox / test organization** for development (never test on live books)
- [ ] Razorpay account in **test mode** keys
- [ ] Domain name bought
- [ ] Grievance officer name, phone, email decided
- [ ] Return, refund, shipping, cancellation policies drafted (lawyer review later)

## How to use (GitHub Codespaces + Netlify)

1. Create a **private** GitHub repo. Upload this whole kit to it (keep the `.devcontainer` and `.claude` folders).
2. Add Codespaces secrets (names in `.devcontainer/devcontainer.json`): GitHub → Settings → Codespaces → Secrets.
3. On the repo: Code → Codespaces → create codespace, **4-core** machine.
4. When it opens, run `claude` in the terminal and log in.
5. Paste `prompts/00-setup.md`. Let it finish. Check `PROGRESS.md`.
6. Connect the repo to Netlify after Phase 00 (storefront only). Steps: `docs/deployment.md`.

Not using Codespaces? Install Claude Code locally (https://code.claude.com/docs/en/overview), Docker and Node 22, then start from step 4.
5. Paste the next prompt only when the previous phase's checklist is ticked.
6. Run `/compliance-check` after phases 03, 05, 06 and 09.
7. Run `/sync-audit` after phases 01, 03, 04 and 05.

## Phase order

| # | Prompt | Result | Rough time |
| --- | --- | --- | --- |
| 00 | Setup | Repo, local services, Medusa + Next.js running | 1 day |
| 01 | Zoho Books client + item/stock sync | Products and stock flow in from Books | 3–5 days |
| 02 | Catalog content | Product pages with legal fields, search, price history | 4–6 days |
| 03 | Checkout + orders to Books | Razorpay, COD + OTP, sales orders in Books | 5–7 days |
| 04 | Fulfilment + payments | Ship, invoice, record payments in Books | 3–5 days |
| 05 | Returns | RMA, QC, credit notes in Books | 3–5 days |
| 06 | Grievance, policies, consent | 2027 consumer rules + DPDP basics | 4–6 days |
| 07 | Admin dashboard + reconcile | Owner metrics, sync health, nightly check | 3–4 days |
| 08 | B2B portal | GSTIN accounts, price lists, credit, bulk order | 5–8 days |
| 09 | Hardening + go-live | Security, load test, DPDP self-service, deploy | 5–7 days |

Times assume one person working with Claude Code full-time. Your speed will vary.

## Safety rules for you

- Review every change Claude Code proposes before approving on production.
- Keep test and live Zoho Books orgs separate. `.env` decides which one.
- Back up the database daily once live.
- Get a lawyer and CA to review policies and GST setup before launch.
